<?php
// Mail Configuration
define('MAIL_HOST', 'smtp.gmail.com'); // Set your SMTP Host
define('MAIL_USERNAME', 'taskflowcore@gmail.com'); // Set your SMTP Username
define('MAIL_PASSWORD', 'fpyv dscl koga qgze'); // Set your SMTP App Password (Not your email password)
define('MAIL_PORT', 587); // TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`
define('MAIL_FROM_ADDRESS', 'taskflowcore@gmail.com');
define('MAIL_FROM_NAME', 'Task Management System');
?>
